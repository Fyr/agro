<?php
class ParamsAppController extends AppController {
     //...
}
?>