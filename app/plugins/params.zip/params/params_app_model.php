<?php
class ParamsAppModel extends AppModel {
       //...
}
?>